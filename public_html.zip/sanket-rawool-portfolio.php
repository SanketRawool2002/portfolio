<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sanket Rawool | 3D Portfolio</title>
    
    <!-- Three.js for 3D Graphics -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <!-- GLTF Loader -->
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.min.js"></script>
    <!-- Orbit Controls -->
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.min.js"></script>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    
    <!-- GSAP Animation -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.11.4/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.11.4/ScrollTrigger.min.js"></script>
    
    <!-- Custom Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #6366f1;
            --secondary-color: #8b5cf6;
            --accent-color: #06b6d4;
            --dark-bg: #0f172a;
            --dark-card: #1e293b;
            --dark-border: #334155;
            --text-primary: #f1f5f9;
            --text-secondary: #cbd5e1;
            --neon-glow: 0 0 20px rgba(99, 102, 241, 0.5);
            --transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--dark-bg);
            color: var(--text-primary);
            line-height: 1.6;
            overflow-x: hidden;
            scroll-behavior: smooth;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
        }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 12px;
        }
        
        ::-webkit-scrollbar-track {
            background: var(--dark-card);
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(to bottom, var(--primary-color), var(--secondary-color));
            border-radius: 6px;
        }
        
        /* Navbar */
        .navbar {
            background: rgba(15, 23, 42, 0.9);
            backdrop-filter: blur(20px);
            padding: 1.2rem 0;
            border-bottom: 1px solid var(--dark-border);
            z-index: 1000;
        }
        
        .navbar-brand {
            font-size: 1.8rem;
            font-weight: 800;
            background: linear-gradient(45deg, var(--primary-color), var(--accent-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            letter-spacing: -0.5px;
        }
        
        .nav-link {
            color: var(--text-secondary) !important;
            font-weight: 500;
            margin: 0 1rem;
            position: relative;
            transition: var(--transition);
        }
        
        .nav-link:hover {
            color: var(--text-primary) !important;
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            left: 0;
            bottom: -5px;
            transition: var(--transition);
        }
        
        .nav-link:hover::after {
            width: 100%;
        }
        
        /* 3D Scene Container */
        #scene-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 0.3;
        }
        
        /* Hero Section */
        .hero-section {
            min-height: 100vh;
            display: flex;
            align-items: center;
            position: relative;
            padding-top: 100px;
            overflow: hidden;
        }
        
        .hero-content {
            position: relative;
            z-index: 10;
        }
        
        .hero-title {
            font-size: 5rem;
            font-weight: 800;
            line-height: 1;
            margin-bottom: 1.5rem;
            background: linear-gradient(45deg, var(--text-primary), var(--accent-color), var(--primary-color));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow: 0 0 30px rgba(99, 102, 241, 0.3);
        }
        
        .hero-subtitle {
            font-size: 1.5rem;
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }
        
        .hero-badge {
            display: inline-block;
            background: rgba(99, 102, 241, 0.1);
            border: 1px solid rgba(99, 102, 241, 0.3);
            color: var(--primary-color);
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
            font-weight: 500;
            margin-right: 1rem;
            margin-bottom: 1rem;
            backdrop-filter: blur(10px);
            transition: var(--transition);
        }
        
        .hero-badge:hover {
            background: rgba(99, 102, 241, 0.2);
            transform: translateY(-3px);
            box-shadow: var(--neon-glow);
        }
        
        /* Floating Elements */
        .floating-element {
            position: absolute;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(99, 102, 241, 0.2), transparent 70%);
            z-index: 1;
        }
        
        /* Glitch Text Effect */
        .glitch {
            position: relative;
            display: inline-block;
        }
        
        .glitch::before,
        .glitch::after {
            content: attr(data-text);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }
        
        .glitch::before {
            left: 2px;
            text-shadow: -2px 0 #ff00ff;
            clip: rect(24px, 550px, 90px, 0);
            animation: glitch-anim 5s infinite linear alternate-reverse;
        }
        
        .glitch::after {
            left: -2px;
            text-shadow: -2px 0 #00ffff;
            clip: rect(85px, 550px, 140px, 0);
            animation: glitch-anim2 5s infinite linear alternate-reverse;
        }
        
        @keyframes glitch-anim {
            0% { clip: rect(42px, 9999px, 44px, 0); }
            5% { clip: rect(12px, 9999px, 59px, 0); }
            10% { clip: rect(48px, 9999px, 29px, 0); }
            15% { clip: rect(42px, 9999px, 73px, 0); }
            20% { clip: rect(63px, 9999px, 27px, 0); }
            25% { clip: rect(34px, 9999px, 55px, 0); }
            30% { clip: rect(86px, 9999px, 73px, 0); }
            35% { clip: rect(20px, 9999px, 20px, 0); }
            40% { clip: rect(26px, 9999px, 60px, 0); }
            45% { clip: rect(25px, 9999px, 66px, 0); }
            50% { clip: rect(57px, 9999px, 98px, 0); }
            55% { clip: rect(5px, 9999px, 46px, 0); }
            60% { clip: rect(82px, 9999px, 31px, 0); }
            65% { clip: rect(54px, 9999px, 27px, 0); }
            70% { clip: rect(28px, 9999px, 99px, 0); }
            75% { clip: rect(45px, 9999px, 69px, 0); }
            80% { clip: rect(23px, 9999px, 85px, 0); }
            85% { clip: rect(54px, 9999px, 84px, 0); }
            90% { clip: rect(45px, 9999px, 47px, 0); }
            95% { clip: rect(37px, 9999px, 20px, 0); }
            100% { clip: rect(4px, 9999px, 91px, 0); }
        }
        
        @keyframes glitch-anim2 {
            0% { clip: rect(65px, 9999px, 100px, 0); }
            5% { clip: rect(52px, 9999px, 74px, 0); }
            10% { clip: rect(79px, 9999px, 85px, 0); }
            15% { clip: rect(75px, 9999px, 5px, 0); }
            20% { clip: rect(67px, 9999px, 61px, 0); }
            25% { clip: rect(14px, 9999px, 79px, 0); }
            30% { clip: rect(1px, 9999px, 66px, 0); }
            35% { clip: rect(86px, 9999px, 30px, 0); }
            40% { clip: rect(23px, 9999px, 98px, 0); }
            45% { clip: rect(85px, 9999px, 72px, 0); }
            50% { clip: rect(71px, 9999px, 75px, 0); }
            55% { clip: rect(2px, 9999px, 48px, 0); }
            60% { clip: rect(30px, 9999px, 16px, 0); }
            65% { clip: rect(59px, 9999px, 50px, 0); }
            70% { clip: rect(41px, 9999px, 62px, 0); }
            75% { clip: rect(2px, 9999px, 82px, 0); }
            80% { clip: rect(47px, 9999px, 73px, 0); }
            85% { clip: rect(3px, 9999px, 27px, 0); }
            90% { clip: rect(40px, 9999px, 86px, 0); }
            95% { clip: rect(45px, 9999px, 72px, 0); }
            100% { clip: rect(23px, 9999px, 49px, 0); }
        }
        
        /* Section Styling */
        .section {
            padding: 100px 0;
            position: relative;
        }
        
        .section-title {
            font-size: 3.5rem;
            margin-bottom: 3rem;
            position: relative;
            display: inline-block;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -10px;
            width: 100px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            border-radius: 2px;
        }
        
        /* 3D Card */
        .card-3d {
            background: var(--dark-card);
            border: 1px solid var(--dark-border);
            border-radius: 20px;
            padding: 2.5rem;
            height: 100%;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(10px);
        }
        
        .card-3d::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            opacity: 0;
            transition: var(--transition);
        }
        
        .card-3d:hover {
            transform: translateY(-15px);
            border-color: var(--primary-color);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3), var(--neon-glow);
        }
        
        .card-3d:hover::before {
            opacity: 1;
        }
        
        /* Skill Orb */
        .skill-orb {
            width: 120px;
            height: 120px;
            position: relative;
            margin: 0 auto;
        }
        
        .orb-circle {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            position: absolute;
            background: conic-gradient(var(--primary-color) 0% 85%, var(--dark-border) 85% 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            animation: rotate 20s linear infinite;
        }
        
        .orb-inner {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: var(--dark-card);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-color);
        }
        
        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Timeline */
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .timeline::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 3px;
            background: linear-gradient(to bottom, var(--primary-color), var(--accent-color));
        }
        
        .timeline-item {
            position: relative;
            margin-bottom: 2.5rem;
            padding-left: 30px;
        }
        
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -8px;
            top: 5px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: var(--primary-color);
            box-shadow: 0 0 15px var(--primary-color);
        }
        
        .timeline-date {
            background: linear-gradient(45deg, var(--primary-color), var(--accent-color));
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
            display: inline-block;
            margin-bottom: 1rem;
            font-weight: 600;
        }
        
        /* Holographic Effect */
        .holographic-card {
            position: relative;
            overflow: hidden;
            border-radius: 20px;
        }
        
        .holographic-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, 
                transparent 30%, 
                rgba(99, 102, 241, 0.1) 50%, 
                transparent 70%);
            transform: translateX(-100%);
            transition: transform 0.6s;
        }
        
        .holographic-card:hover::before {
            transform: translateX(100%);
        }
        
        /* Contact Form */
        .form-control {
            background: var(--dark-card);
            border: 1px solid var(--dark-border);
            color: var(--text-primary);
            padding: 1rem;
            border-radius: 10px;
            transition: var(--transition);
        }
        
        .form-control:focus {
            background: var(--dark-card);
            border-color: var(--primary-color);
            color: var(--text-primary);
            box-shadow: 0 0 0 0.25rem rgba(99, 102, 241, 0.25);
        }
        
        /* Button */
        .btn-neon {
            background: linear-gradient(45deg, var(--primary-color), var(--accent-color));
            color: white;
            border: none;
            padding: 1rem 2.5rem;
            border-radius: 50px;
            font-weight: 600;
            position: relative;
            overflow: hidden;
            transition: var(--transition);
            z-index: 1;
        }
        
        .btn-neon::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, var(--accent-color), var(--primary-color));
            z-index: -1;
            opacity: 0;
            transition: var(--transition);
        }
        
        .btn-neon:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(99, 102, 241, 0.4);
        }
        
        .btn-neon:hover::before {
            opacity: 1;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero-title {
                font-size: 3rem;
            }
            
            .section-title {
                font-size: 2.5rem;
            }
            
            .hero-subtitle {
                font-size: 1.2rem;
            }
        }
        
        /* Particle Text */
        .particle-text {
            position: relative;
            display: inline-block;
        }
        
        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: var(--accent-color);
            border-radius: 50%;
            pointer-events: none;
            opacity: 0;
        }
    </style>
</head>
<body>
    <!-- 3D Background Scene -->
    <div id="scene-container"></div>
    
    <!-- Floating Elements -->
    <div class="floating-element" style="width: 300px; height: 300px; top: 10%; left: 5%;"></div>
    <div class="floating-element" style="width: 200px; height: 200px; bottom: 20%; right: 10%;"></div>
    <div class="floating-element" style="width: 150px; height: 150px; top: 50%; left: 80%;"></div>
    
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">SANKET RAWOOL</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#skills">Skills</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#experience">Experience</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#projects">Projects</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="hero-content">
                        <h1 class="hero-title glitch" data-text="SANKET RAWOOL">SANKET RAWOOL</h1>
                        <h2 class="hero-subtitle">Full Stack Developer</h2>
                        <p class="lead mb-4">Crafting immersive digital experiences with cutting-edge technology and innovative solutions.</p>
                        
                        <div class="mb-4">
                            <span class="hero-badge"><i class="bi bi-geo-alt me-2"></i>Mumbai, Maharashtra</span>
                            <span class="hero-badge"><i class="bi bi-phone me-2"></i>9967911477</span>
                            <span class="hero-badge"><i class="bi bi-envelope me-2"></i>sankyraul1989@gmail.com</span>
                        </div>
                        
                        <a href="#contact" class="btn btn-neon me-3">
                            <i class="bi bi-send me-2"></i>Contact Me
                        </a>
                        <a href="#projects" class="btn btn-outline-primary border-2">
                            <i class="bi bi-code-slash me-2"></i>View Projects
                        </a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <!-- 3D Model Placeholder -->
                    <div id="model-container" style="height: 500px; width: 100%;"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="section">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">PROFILE SUMMARY</h2>
            <div class="row">
                <div class="col-lg-10 mx-auto">
                    <div class="card-3d" data-aos="fade-up">
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <p class="fs-5">
                                    Motivated and detail-oriented Web Developer with a strong foundation in frontend and backend technologies. Hands-on experience in building responsive web applications, ERP/LMS systems, and live server deployments. Quick learner with a passion for modern frameworks, problem-solving, and delivering efficient, scalable solutions.
                                </p>
                            </div>
                            <div class="col-lg-4 text-center">
                                <div class="skill-orb">
                                    <div class="orb-circle">
                                        <div class="orb-inner">
                                            <i class="bi bi-code-slash"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Skills Section -->
    <section id="skills" class="section bg-dark">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">TECHNICAL EXPERTISE</h2>
            <div class="row g-4">
                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="card-3d holographic-card">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-primary bg-opacity-10 p-2 rounded me-3">
                                <i class="bi bi-layout-wtf text-primary fs-3"></i>
                            </div>
                            <h3 class="mb-0">Frontend</h3>
                        </div>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-primary me-2"></i>HTML5 & CSS3</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-primary me-2"></i>JavaScript (ES6+)</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-primary me-2"></i>Bootstrap 5</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-primary me-2"></i>React.js</li>
                            <li><i class="bi bi-check-circle-fill text-primary me-2"></i>jQuery</li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="card-3d holographic-card">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-secondary bg-opacity-10 p-2 rounded me-3">
                                <i class="bi bi-server text-secondary fs-3"></i>
                            </div>
                            <h3 class="mb-0">Backend</h3>
                        </div>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-secondary me-2"></i>PHP</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-secondary me-2"></i>Java</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-secondary me-2"></i>Laravel</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-secondary me-2"></i>API Integration</li>
                            <li><i class="bi bi-check-circle-fill text-secondary me-2"></i>RESTful Services</li>
                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="card-3d holographic-card">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-accent bg-opacity-10 p-2 rounded me-3">
                                <i class="bi bi-tools text-accent fs-3"></i>
                            </div>
                            <h3 class="mb-0">Other Skills</h3>
                        </div>
                        <ul class="list-unstyled">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-accent me-2"></i>MySQL & SQL</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-accent me-2"></i>Live Server Deployment</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-accent me-2"></i>Basic Hardware & Networking</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-accent me-2"></i>Git & Version Control</li>
                            <li><i class="bi bi-check-circle-fill text-accent me-2"></i>UI/UX Design Principles</li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Soft Skills -->
            <h2 class="section-title mt-5" data-aos="fade-up">SOFT SKILLS</h2>
            <div class="row g-4 mt-3">
                <div class="col-md-3 col-6" data-aos="zoom-in" data-aos-delay="100">
                    <div class="card-3d text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-arrow-repeat text-primary fs-1"></i>
                        </div>
                        <h5>Adaptability</h5>
                    </div>
                </div>
                <div class="col-md-3 col-6" data-aos="zoom-in" data-aos-delay="200">
                    <div class="card-3d text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-chat-dots text-primary fs-1"></i>
                        </div>
                        <h5>Communication</h5>
                    </div>
                </div>
                <div class="col-md-3 col-6" data-aos="zoom-in" data-aos-delay="300">
                    <div class="card-3d text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-lightning-charge text-primary fs-1"></i>
                        </div>
                        <h5>Problem-Solving</h5>
                    </div>
                </div>
                <div class="col-md-3 col-6" data-aos="zoom-in" data-aos-delay="400">
                    <div class="card-3d text-center p-4">
                        <div class="mb-3">
                            <i class="bi bi-clock text-primary fs-1"></i>
                        </div>
                        <h5>Multitasking</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Experience Section -->
    <section id="experience" class="section">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">WORK EXPERIENCE</h2>
            <div class="row">
                <div class="col-lg-10 mx-auto">
                    <div class="card-3d" data-aos="fade-up">
                        <div class="d-flex align-items-start mb-4">
                            <div class="flex-grow-1">
                                <h3 class="mb-1">Web Developer</h3>
                                <h4 class="text-primary mb-3">ISBM Organization — Mumbai</h4>
                            </div>
                            <span class="timeline-date">April 2024 – Present</span>
                        </div>
                        
                        <div class="timeline">
                            <div class="timeline-item">
                                <p>Significantly improved technical skills in Bootstrap, JavaScript, jQuery, and PHP, enabling the development of responsive and dynamic web applications.</p>
                            </div>
                            <div class="timeline-item">
                                <p>Gained practical experience with React and Laravel, implementing component-based UI, API integration, routing, and MVC architecture in real university projects.</p>
                            </div>
                            <div class="timeline-item">
                                <p>Contributed to the University Lead Management System (Insity) by integrating WhatsApp chat, enabling real-time messaging, media sharing, and direct lead communication.</p>
                            </div>
                            <div class="timeline-item">
                                <p>Played a key role in the development and maintenance of ERP and LMS systems, including UI enhancements, backend feature implementation, bug fixing, and module updates.</p>
                            </div>
                            <div class="timeline-item">
                                <p>Learned and handled live server deployments, including domain configuration, database setup, and file structure management.</p>
                            </div>
                            <div class="timeline-item">
                                <p>Integrated Telegram notifications and WhatsApp bot automation to enhance real-time communication and system updates.</p>
                            </div>
                            <div class="timeline-item">
                                <p>Developed and enhanced a Task Management Web Application with features like task delegation, frequency management, reminders, and scheduled meetings.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Projects Section -->
    <section id="projects" class="section bg-dark">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">PROJECTS & EDUCATION</h2>
            <div class="row g-4">
                <div class="col-lg-6" data-aos="fade-right">
                    <div class="card-3d h-100">
                        <h3 class="mb-4">Academic Project</h3>
                        <h4 class="text-primary mb-3">Complaint Management System</h4>
                        <p>Developed a web-based complaint management system using HTML, CSS, JavaScript, PHP, enabling efficient complaint registration and tracking.</p>
                        <div class="mt-4">
                            <span class="badge bg-primary me-2 p-2">HTML5</span>
                            <span class="badge bg-primary me-2 p-2">CSS3</span>
                            <span class="badge bg-primary me-2 p-2">JavaScript</span>
                            <span class="badge bg-primary me-2 p-2">PHP</span>
                            <span class="badge bg-primary me-2 p-2">MySQL</span>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-6" data-aos="fade-left">
                    <div class="card-3d h-100">
                        <h3 class="mb-4">Education</h3>
                        <div class="mb-4">
                            <h5>Bachelor of Science in Information Technology (BSc IT)</h5>
                            <p class="text-secondary">Mumbai University — 2023</p>
                            <p><strong>CGPI:</strong> 8.92</p>
                        </div>
                        <div class="mb-4">
                            <h5>HSC (Class XII)</h5>
                            <p class="text-secondary">Maharashtra Board — 2020</p>
                            <p><strong>Percentage:</strong> 62.46%</p>
                        </div>
                        <div>
                            <h5>SSC (Class X)</h5>
                            <p class="text-secondary">Maharashtra Board — 2018</p>
                            <p><strong>Percentage:</strong> 84.80%</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="section">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">GET IN TOUCH</h2>
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="card-3d" data-aos="fade-up">
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="contact-info">
                                    <h4 class="mb-4">Personal Details</h4>
                                    <div class="mb-3">
                                        <p><strong>Date of Birth:</strong> 06 December 2002</p>
                                        <p><strong>Gender:</strong> Male</p>
                                        <p><strong>Marital Status:</strong> Single</p>
                                        <p><strong>Location:</strong> Mumbai, Maharashtra</p>
                                    </div>
                                    
                                    <h4 class="mb-3">Languages</h4>
                                    <div class="d-flex flex-wrap gap-2 mb-4">
                                        <span class="badge bg-primary p-2">English</span>
                                        <span class="badge bg-primary p-2">Hindi</span>
                                        <span class="badge bg-primary p-2">Marathi</span>
                                    </div>
                                    
                                    <h4 class="mb-3">Hobbies</h4>
                                    <div class="row g-2">
                                        <div class="col-6">
                                            <div class="hobby-item p-3 rounded bg-dark">
                                                <i class="bi bi-book me-2"></i>Reading
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="hobby-item p-3 rounded bg-dark">
                                                <i class="bi bi-airplane me-2"></i>Traveling
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="hobby-item p-3 rounded bg-dark">
                                                <i class="bi bi-controller me-2"></i>Gaming
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="hobby-item p-3 rounded bg-dark">
                                                <i class="bi bi-palette me-2"></i>Drawing
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <h4 class="mb-4">Contact Information</h4>
                                <div class="mb-3">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="bg-primary bg-opacity-10 p-2 rounded me-3">
                                            <i class="bi bi-telephone text-primary"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Phone</h6>
                                            <p class="mb-0">+91 9967911477</p>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="bg-primary bg-opacity-10 p-2 rounded me-3">
                                            <i class="bi bi-envelope text-primary"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Email</h6>
                                            <p class="mb-0">sankyraul1989@gmail.com</p>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary bg-opacity-10 p-2 rounded me-3">
                                            <i class="bi bi-geo-alt text-primary"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Location</h6>
                                            <p class="mb-0">Mumbai, Maharashtra</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mt-4">
                                    <a href="mailto:sankyraul1989@gmail.com" class="btn btn-neon w-100">
                                        <i class="bi bi-envelope me-2"></i>Send Message
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-4 border-top border-dark">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h4 class="mb-3">SANKET RAWOOL</h4>
                    <p class="text-secondary mb-0">Full Stack Developer & Digital Solution Architect</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0">© 2024 Sanket Rawool. All rights reserved.</p>
                    <p class="text-secondary">Portfolio v2.0 | Advanced 3D Edition</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Main Script -->
    <script>
        // Initialize GSAP
        gsap.registerPlugin(ScrollTrigger);
        
        // 3D Scene Setup
        let scene, camera, renderer, controls;
        
        function init3DScene() {
            // Scene
            scene = new THREE.Scene();
            
            // Camera
            camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.z = 5;
            
            // Renderer
            renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            document.getElementById('scene-container').appendChild(renderer.domElement);
            
            // Lights
            const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
            scene.add(ambientLight);
            
            const directionalLight = new THREE.DirectionalLight(0x6366f1, 1);
            directionalLight.position.set(5, 5, 5);
            scene.add(directionalLight);
            
            // Create geometric objects
            createGeometricObjects();
            
            // Orbit Controls
            controls = new THREE.OrbitControls(camera, renderer.domElement);
            controls.enableZoom = false;
            controls.enablePan = false;
            controls.autoRotate = true;
            controls.autoRotateSpeed = 0.5;
            
            // Handle window resize
            window.addEventListener('resize', onWindowResize);
            
            // Start animation
            animate();
        }
        
        function createGeometricObjects() {
            // Create a torus knot
            const geometry = new THREE.TorusKnotGeometry(1, 0.3, 100, 16);
            const material = new THREE.MeshPhysicalMaterial({
                color: 0x6366f1,
                metalness: 0.8,
                roughness: 0.2,
                clearcoat: 1,
                clearcoatRoughness: 0.1,
                transmission: 0.9,
                opacity: 0.8,
                transparent: true
            });
            
            const torusKnot = new THREE.Mesh(geometry, material);
            scene.add(torusKnot);
            
            // Create floating cubes
            for (let i = 0; i < 50; i++) {
                const size = Math.random() * 0.1 + 0.05;
                const cubeGeometry = new THREE.BoxGeometry(size, size, size);
                const cubeMaterial = new THREE.MeshBasicMaterial({
                    color: Math.random() * 0xffffff,
                    transparent: true,
                    opacity: 0.6
                });
                
                const cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
                
                // Random position
                cube.position.x = (Math.random() - 0.5) * 20;
                cube.position.y = (Math.random() - 0.5) * 20;
                cube.position.z = (Math.random() - 0.5) * 20;
                
                scene.add(cube);
                
                // Store animation properties
                cube.userData = {
                    speed: Math.random() * 0.02 + 0.01,
                    rotationSpeed: Math.random() * 0.02 + 0.01
                };
            }
        }
        
        function onWindowResize() {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }
        
        function animate() {
            requestAnimationFrame(animate);
            
            // Rotate all objects
            scene.children.forEach(child => {
                if (child.userData && child.userData.rotationSpeed) {
                    child.rotation.x += child.userData.speed;
                    child.rotation.y += child.userData.rotationSpeed;
                }
            });
            
            controls.update();
            renderer.render(scene, camera);
        }
        
        // Initialize when page loads
        window.addEventListener('load', () => {
            init3DScene();
            
            // GSAP Animations
            gsap.from('.hero-title', {
                duration: 1.5,
                y: 100,
                opacity: 0,
                ease: 'power4.out'
            });
            
            gsap.from('.hero-subtitle', {
                duration: 1.5,
                y: 50,
                opacity: 0,
                delay: 0.5,
                ease: 'power4.out'
            });
            
            // Animate cards on scroll
            gsap.utils.toArray('.card-3d').forEach(card => {
                gsap.from(card, {
                    scrollTrigger: {
                        trigger: card,
                        start: 'top 80%',
                        end: 'bottom 20%',
                        toggleActions: 'play none none reverse'
                    },
                    y: 50,
                    opacity: 0,
                    duration: 1,
                    ease: 'power3.out'
                });
            });
            
            // Particle text effect
            const textElements = document.querySelectorAll('.particle-text');
            textElements.forEach(text => {
                text.addEventListener('mouseenter', createParticleEffect);
            });
        });
        
        function createParticleEffect(e) {
            const text = e.target;
            const textRect = text.getBoundingClientRect();
            
            for (let i = 0; i < 50; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                const size = Math.random() * 3 + 1;
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                
                const x = Math.random() * textRect.width;
                const y = Math.random() * textRect.height;
                
                particle.style.left = `${x}px`;
                particle.style.top = `${y}px`;
                
                text.appendChild(particle);
                
                // Animate particle
                gsap.to(particle, {
                    x: (Math.random() - 0.5) * 100,
                    y: (Math.random() - 0.5) * 100,
                    opacity: 0,
                    duration: 1,
                    ease: 'power2.out',
                    onComplete: () => {
                        particle.remove();
                    }
                });
            }
        }
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });
        
        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.querySelector('.navbar');
            if (window.scrollY > 100) {
                navbar.style.padding = '0.8rem 0';
                navbar.style.backdropFilter = 'blur(20px)';
            } else {
                navbar.style.padding = '1.2rem 0';
                navbar.style.backdropFilter = 'blur(20px)';
            }
        });
    </script>
</body>
</html>